#!/bin/sh
set -x
rm -f aclocal.m4
rm -rf build-aux
rm -rf msvc
rm -rf fused-src
rm -f configure configure.ac
rm -f Makefile.in Makefile.am
rm -rf xcode
rm -rf test
rm -rf m4
rm -rf make
rm -rf codegear
rm -rf samples
rm -rf scripts
