// This file exists merely to let libtool link us as a C++ target
