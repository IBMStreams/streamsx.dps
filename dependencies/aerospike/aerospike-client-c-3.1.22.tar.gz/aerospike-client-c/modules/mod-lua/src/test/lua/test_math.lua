local exports = {}

function exports.add(a,b)
    return a + b
end

return exports