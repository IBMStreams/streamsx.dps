char* aerospike_client_version = "3.1.26";
