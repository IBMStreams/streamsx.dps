
function udf_basics()
    return 1
end
